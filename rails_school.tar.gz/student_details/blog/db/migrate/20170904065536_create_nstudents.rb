class CreateNstudents < ActiveRecord::Migration[5.1]
  def change
    create_table :nstudents do |t|
      t.string :name
      t.string :lastname
      t.integer :age
      t.references :student, foreign_key: true

      t.timestamps
    end
  end
end
