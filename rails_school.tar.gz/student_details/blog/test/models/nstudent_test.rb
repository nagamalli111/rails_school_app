require 'test_helper'

class NstudentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
