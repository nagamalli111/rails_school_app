class Student < ApplicationRecord
	validates :name, :lastname, :age, presence: true

	has_many :nstudents,  dependent: :destroy
	
	            

end
