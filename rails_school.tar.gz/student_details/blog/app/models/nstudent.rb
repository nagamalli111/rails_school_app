class Nstudent < ApplicationRecord
  belongs_to :student
end
