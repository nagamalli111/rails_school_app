class NstudentsController < ApplicationController

  def index
    
  end

  def show

    @student = Student.find(params[:student_id])
    @nstudent = @student.nstudents.find(params[:id])

    redirect_to student_path(@student)

  end

	def create
    @student = Student.find(params[:student_id])
    @nstudent = @student.nstudents.create(nstudent_params)
    redirect_to student_path(@student)
  end

  def update
    @student = Student.find(params[:student_id])

     @nstudent = @student.nstudents.find(params[:id])

    @nstudent.update(nstudent_params)


    redirect_to student_path(@student)
  end

  def edit
    @student = Student.find(params[:student_id])

    @nstudent = @student.nstudents.find(params[:id])
  end

    def destroy
    @student = Student.find(params[:student_id])

    @nstudent = @student.nstudents.find(params[:id])

    @nstudent.destroy

    redirect_to student_path(@student)
  end


 
  private
    def nstudent_params
      params.require(:nstudent).permit(:name, :lastname, :age)
    end
end
 